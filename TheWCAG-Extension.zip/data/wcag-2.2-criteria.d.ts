import { WcagCriterion, WcagLevel, WcagPrinciple } from '../types';
export declare const wcag22Criteria: WcagCriterion[];
/**
 * Get all criteria for a specific level (cumulative)
 */
export declare function getCriteriaByLevel(level: WcagLevel): WcagCriterion[];
/**
 * Get criteria for exactly one level
 */
export declare function getCriteriaForExactLevel(level: WcagLevel): WcagCriterion[];
/**
 * Get criteria by principle
 */
export declare function getCriteriaByPrinciple(principle: WcagPrinciple): WcagCriterion[];
/**
 * Get new criteria in WCAG 2.2
 */
export declare function getNewIn22(): WcagCriterion[];
/**
 * Get criterion by ID
 */
export declare function getCriterionById(id: string): WcagCriterion | undefined;
/**
 * Get criteria that can be fully automated
 */
export declare function getAutomatableCriteria(): WcagCriterion[];
/**
 * Get criteria that require manual testing
 */
export declare function getManualCriteria(): WcagCriterion[];
/**
 * Get criteria by related rule
 */
export declare function getCriteriaByRule(ruleId: string): WcagCriterion[];
/**
 * Get count statistics
 */
export declare function getWcagStats(): {
    total: number;
    byLevel: Record<WcagLevel, number>;
    byPrinciple: Record<WcagPrinciple, number>;
    newIn22: number;
    automatable: {
        full: number;
        partial: number;
        manual: number;
    };
};
//# sourceMappingURL=wcag-2.2-criteria.d.ts.map