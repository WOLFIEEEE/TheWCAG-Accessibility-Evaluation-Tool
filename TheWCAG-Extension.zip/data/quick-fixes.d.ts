import { QuickFix } from '../types';
export declare const quickFixes: Record<string, QuickFix>;
/**
 * Get quick fix for a rule ID
 */
export declare function getQuickFix(ruleId: string): QuickFix | undefined;
/**
 * Get all available quick fixes
 */
export declare function getAllQuickFixes(): QuickFix[];
/**
 * Get quick fixes by WCAG criterion
 */
export declare function getQuickFixesByCriterion(criterionId: string): QuickFix[];
/**
 * Check if a rule has a quick fix available
 */
export declare function hasQuickFix(ruleId: string): boolean;
/**
 * Get quick fix rule IDs
 */
export declare function getQuickFixRuleIds(): string[];
//# sourceMappingURL=quick-fixes.d.ts.map