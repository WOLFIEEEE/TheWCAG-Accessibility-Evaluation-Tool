import { AccessibilityRule } from '../../types';
export declare const contrastRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map