import { AccessibilityRule } from '../../types';
export declare const alertRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map