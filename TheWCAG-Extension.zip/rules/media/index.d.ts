import { AccessibilityRule } from '../../types';
export declare const mediaRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map