import { AccessibilityRule } from '../../types';
export declare const featureRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map