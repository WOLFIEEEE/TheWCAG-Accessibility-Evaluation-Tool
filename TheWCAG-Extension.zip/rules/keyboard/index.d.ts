import { AccessibilityRule } from '../../types';
export declare const keyboardRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map