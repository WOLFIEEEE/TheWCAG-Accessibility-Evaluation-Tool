import { AccessibilityRule } from '../../types';
export declare const structureRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map