import { AccessibilityRule } from '../../types';
export declare const ariaRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map