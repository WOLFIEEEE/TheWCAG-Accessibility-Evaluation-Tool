import { AccessibilityRule } from '../../types';
export declare const mobileRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map