import { AccessibilityRule } from '../../types';
export declare const errorRules: AccessibilityRule[];
//# sourceMappingURL=index.d.ts.map