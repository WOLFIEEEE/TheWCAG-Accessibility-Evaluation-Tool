import { AccessibilityRule, RuleDocumentation, EvaluationContext, RuleResult } from '../types';
/**
 * Creates a rule with proper defaults
 */
export declare function createRule(id: string, name: string, category: 'error' | 'alert' | 'feature' | 'structure' | 'aria' | 'contrast', options: {
    description: string;
    impact: 'critical' | 'serious' | 'moderate' | 'minor' | 'none';
    wcagCriteria: string[];
    wcagLevel: 'A' | 'AA' | 'AAA';
    tags: string[];
    evaluate: (element: Element, context: EvaluationContext) => RuleResult | null;
    documentation?: Partial<RuleDocumentation>;
}): AccessibilityRule;
/**
 * All accessibility rules organized by category
 */
export declare const rulesByCategory: {
    error: AccessibilityRule[];
    alert: AccessibilityRule[];
    feature: AccessibilityRule[];
    structure: AccessibilityRule[];
    aria: AccessibilityRule[];
    contrast: AccessibilityRule[];
};
/**
 * All rules as a flat array
 */
export declare const allRules: AccessibilityRule[];
/**
 * Rule lookup by ID
 */
export declare const rulesById: Map<string, AccessibilityRule>;
/**
 * Get a rule by ID
 */
export declare function getRule(id: string): AccessibilityRule | undefined;
/**
 * Get all rules for a category
 */
export declare function getRulesByCategory(category: string): AccessibilityRule[];
/**
 * Get all rules with a specific tag
 */
export declare function getRulesByTag(tag: string): AccessibilityRule[];
/**
 * Get all rules for a WCAG criterion
 */
export declare function getRulesByWcag(criterion: string): AccessibilityRule[];
/**
 * Run all rules against a document
 */
export declare function evaluateDocument(doc: Document, options?: {
    categories?: string[];
    tags?: string[];
    wcagLevel?: 'A' | 'AA' | 'AAA';
}): Promise<RuleResult[]>;
/**
 * Get statistics from evaluation results
 */
export declare function getResultStatistics(results: RuleResult[]): {
    errors: number;
    alerts: number;
    features: number;
    structure: number;
    aria: number;
    contrast: number;
};
/**
 * Group results by rule ID
 */
export declare function groupResultsByRule(results: RuleResult[]): Map<string, RuleResult[]>;
/**
 * Group results by category
 */
export declare function groupResultsByCategory(results: RuleResult[]): Map<string, RuleResult[]>;
/**
 * Evaluate a page and return grouped results
 * This provides a grouped results format for the evaluation
 */
export declare function evaluatePage(doc: Document): Promise<{
    categories: {
        error: RuleResult[];
        alert: RuleResult[];
        feature: RuleResult[];
        structure: RuleResult[];
        aria: RuleResult[];
        contrast: RuleResult[];
    };
    statistics: {
        totalElements: number;
        pageTitle: string;
        errors: number;
        alerts: number;
        features: number;
        structure: number;
        aria: number;
        contrast: number;
    };
}>;
export { errorRules } from './errors';
export { alertRules } from './alerts';
export { featureRules } from './features';
export { structureRules } from './structure';
export { ariaRules } from './aria';
export { contrastRules } from './contrast';
export { keyboardRules } from './keyboard';
export { mobileRules } from './mobile';
export { mediaRules } from './media';
//# sourceMappingURL=index.d.ts.map