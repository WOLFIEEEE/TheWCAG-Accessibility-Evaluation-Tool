import { WcagCriterion, WcagLevel, CriterionStatus, ComplianceReport, EvaluationResults, RuleResult } from '../types';
/**
 * Determine the status of a criterion based on evaluation results
 */
export declare function getCriterionStatus(criterion: WcagCriterion, results: EvaluationResults): {
    status: CriterionStatus;
    issues: RuleResult[];
};
/**
 * Check if a criterion is applicable to the page
 */
export declare function isCriterionApplicable(criterion: WcagCriterion, results: EvaluationResults): boolean;
/**
 * Generate a comprehensive compliance report
 */
export declare function generateComplianceReport(results: EvaluationResults, targetLevel: WcagLevel): ComplianceReport;
/**
 * Get a checklist of items requiring manual testing
 */
export declare function getManualTestChecklist(targetLevel: WcagLevel): {
    criterion: WcagCriterion;
    testInstructions: string;
}[];
/**
 * Get WCAG criteria related to a specific rule result
 */
export declare function getCriteriaForIssue(issue: RuleResult): WcagCriterion[];
/**
 * Get a summary of issues grouped by WCAG criterion
 */
export declare function groupIssuesByCriterion(results: EvaluationResults): Map<string, {
    criterion: WcagCriterion;
    issues: RuleResult[];
}>;
/**
 * Calculate a compliance score (0-100)
 */
export declare function calculateComplianceScore(report: ComplianceReport): number;
/**
 * Get compliance level achieved
 */
export declare function getAchievedLevel(results: EvaluationResults): WcagLevel | null;
/**
 * Export compliance report as formatted text
 */
export declare function exportComplianceAsText(report: ComplianceReport): string;
/**
 * Export compliance report for CSV
 */
export declare function exportComplianceAsCsv(report: ComplianceReport): string;
//# sourceMappingURL=compliance-checker.d.ts.map