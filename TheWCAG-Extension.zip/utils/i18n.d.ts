/**
 * Get a localized message from the _locales folder
 * @param messageName - The name of the message as defined in messages.json
 * @param substitutions - Optional array of substitution strings
 * @returns The localized message or the messageName if not found
 */
export declare function getMessage(messageName: string, substitutions?: string | string[]): string;
/**
 * Get the UI language
 */
export declare function getUILanguage(): string;
/**
 * Get all available accept languages in order of preference
 */
export declare function getAcceptLanguages(): Promise<string[]>;
/**
 * Check if a language is RTL (right-to-left)
 */
export declare function isRTL(languageCode?: string): boolean;
/**
 * Format a number according to the user's locale
 */
export declare function formatNumber(value: number, options?: Intl.NumberFormatOptions): string;
/**
 * Format a date according to the user's locale
 */
export declare function formatDate(date: Date, options?: Intl.DateTimeFormatOptions): string;
/**
 * Format a relative time (e.g., "2 hours ago")
 */
export declare function formatRelativeTime(date: Date): string;
/**
 * Pluralize a message based on count
 */
export declare function pluralize(count: number, singular: string, plural: string, zero?: string): string;
/**
 * Common messages with fallbacks
 */
export declare const messages: {
    tabDetails: () => string;
    tabReference: () => string;
    tabOrder: () => string;
    tabStructure: () => string;
    tabContrast: () => string;
    categoryErrors: () => string;
    categoryAlerts: () => string;
    categoryFeatures: () => string;
    categoryStructure: () => string;
    categoryAria: () => string;
    categoryContrast: () => string;
    loading: () => string;
    noErrors: () => string;
    manualTestingNote: () => string;
    aimScore: () => string;
    outOf10: () => string;
    searchPlaceholder: () => string;
    viewDocumentation: () => string;
    inspectElement: () => string;
    exportJSON: () => string;
    exportCSV: () => string;
    exportHTML: () => string;
    exportCopy: () => string;
    pass: () => string;
    fail: () => string;
    reportGenerated: () => string;
    reportCopied: () => string;
    exportFailed: () => string;
};
/**
 * Apply translations to DOM elements with data-i18n attribute
 */
export declare function translateDocument(root?: Document | Element): void;
/**
 * Set document direction based on language
 */
export declare function setDocumentDirection(doc?: Document): void;
declare const _default: {
    getMessage: typeof getMessage;
    getUILanguage: typeof getUILanguage;
    getAcceptLanguages: typeof getAcceptLanguages;
    isRTL: typeof isRTL;
    formatNumber: typeof formatNumber;
    formatDate: typeof formatDate;
    formatRelativeTime: typeof formatRelativeTime;
    pluralize: typeof pluralize;
    messages: {
        tabDetails: () => string;
        tabReference: () => string;
        tabOrder: () => string;
        tabStructure: () => string;
        tabContrast: () => string;
        categoryErrors: () => string;
        categoryAlerts: () => string;
        categoryFeatures: () => string;
        categoryStructure: () => string;
        categoryAria: () => string;
        categoryContrast: () => string;
        loading: () => string;
        noErrors: () => string;
        manualTestingNote: () => string;
        aimScore: () => string;
        outOf10: () => string;
        searchPlaceholder: () => string;
        viewDocumentation: () => string;
        inspectElement: () => string;
        exportJSON: () => string;
        exportCSV: () => string;
        exportHTML: () => string;
        exportCopy: () => string;
        pass: () => string;
        fail: () => string;
        reportGenerated: () => string;
        reportCopied: () => string;
        exportFailed: () => string;
    };
    translateDocument: typeof translateDocument;
    setDocumentDirection: typeof setDocumentDirection;
};
export default _default;
//# sourceMappingURL=i18n.d.ts.map