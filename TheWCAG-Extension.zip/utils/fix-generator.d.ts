import { GeneratedFix, RuleResult, FixPlaceholder } from '../types';
/**
 * Get the outer HTML of an element with length limits
 */
export declare function getElementOuterHTML(element: Element, maxLength?: number): string;
/**
 * Get a CSS selector for an element
 */
export declare function getSelector(element: Element): string;
/**
 * Get an attribute value from an element
 */
export declare function getAttribute(element: Element, attrName: string): string;
/**
 * Get text content from an element
 */
export declare function getTextContent(element: Element): string;
/**
 * Get the tag name of an element
 */
export declare function getTagName(element: Element): string;
/**
 * Generate a unique ID based on element characteristics
 */
export declare function generateId(element: Element): string;
/**
 * Preserve other attributes from the element
 */
export declare function preserveAttributes(element: Element, excludeAttrs?: string[]): string;
/**
 * Auto-generate a placeholder value based on the element
 */
export declare function autoGeneratePlaceholder(placeholder: FixPlaceholder, element: Element): string;
/**
 * Apply placeholder values to a template
 */
export declare function applyPlaceholders(template: string, values: Record<string, string>): string;
/**
 * Generate a fix for a rule result
 */
export declare function generateFix(ruleId: string, element: Element): GeneratedFix | null;
/**
 * Generate fixes for multiple results
 */
export declare function generateFixesForResults(results: RuleResult[]): Map<string, GeneratedFix | null>;
/**
 * Get contextual suggestions for a fix
 */
export declare function getFixSuggestions(ruleId: string, element: Element): string[];
/**
 * Format HTML code for display
 */
export declare function formatHtml(html: string): string;
/**
 * Escape HTML for display
 */
export declare function escapeHtml(html: string): string;
declare const _default: {
    generateFix: typeof generateFix;
    applyPlaceholders: typeof applyPlaceholders;
    getElementOuterHTML: typeof getElementOuterHTML;
    getFixSuggestions: typeof getFixSuggestions;
    formatHtml: typeof formatHtml;
    escapeHtml: typeof escapeHtml;
};
export default _default;
//# sourceMappingURL=fix-generator.d.ts.map