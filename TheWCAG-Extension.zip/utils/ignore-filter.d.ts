import { IgnorePattern, RuleResult } from '../types';
/**
 * Check if a selector matches a pattern
 * Supports wildcards (*) and partial matches
 */
export declare function matchSelector(selector: string, pattern: string): boolean;
/**
 * Check if a URL matches a domain pattern
 * Supports wildcards and subdomains
 */
export declare function matchDomain(url: string, pattern: string): boolean;
/**
 * Check if a rule ID matches a pattern
 */
export declare function matchRule(ruleId: string, pattern: string): boolean;
/**
 * Check if an element matches a pattern by its attributes
 */
export declare function matchElement(element: {
    selector: string;
    tagName?: string;
    id?: string;
    classes?: string[];
}, pattern: string): boolean;
/**
 * Check if a result should be ignored based on patterns
 */
export declare function shouldIgnore(result: RuleResult, patterns: IgnorePattern[], pageUrl?: string): boolean;
/**
 * Filter results, removing ignored ones
 */
export declare function filterResults(results: RuleResult[], patterns: IgnorePattern[], pageUrl?: string): RuleResult[];
/**
 * Get ignored results (for showing what was filtered)
 */
export declare function getIgnoredResults(results: RuleResult[], patterns: IgnorePattern[], pageUrl?: string): {
    result: RuleResult;
    pattern: IgnorePattern;
}[];
/**
 * Validate an ignore pattern
 */
export declare function validatePattern(pattern: Partial<IgnorePattern>): {
    valid: boolean;
    errors: string[];
};
/**
 * Suggest patterns based on a result
 */
export declare function suggestPatterns(result: RuleResult): IgnorePattern[];
/**
 * Get statistics about what patterns are matching
 */
export declare function getPatternStats(results: RuleResult[], patterns: IgnorePattern[], pageUrl?: string): Map<string, number>;
//# sourceMappingURL=ignore-filter.d.ts.map