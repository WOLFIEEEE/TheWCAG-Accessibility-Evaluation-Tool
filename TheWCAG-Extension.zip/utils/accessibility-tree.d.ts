import { AccessibleNode } from '../types';
/**
 * Get the accessible name of an element
 * Implements accessible name computation (simplified)
 */
export declare function getAccessibleName(element: Element): string;
/**
 * Get the accessible description of an element
 */
export declare function getAccessibleDescription(element: Element): string;
/**
 * Get the accessible role of an element
 */
export declare function getAccessibleRole(element: Element): string;
/**
 * Get ARIA states for an element
 */
export declare function getAriaStates(element: Element): string[];
/**
 * Get ARIA properties for an element
 */
export declare function computeAriaProperties(element: Element): Record<string, string>;
/**
 * Generate a CSS selector for an element
 */
export declare function getSelectorForElement(element: Element): string;
/**
 * Build the complete accessibility tree
 */
export declare function buildAccessibilityTree(root?: Element): AccessibleNode;
/**
 * Flatten the accessibility tree to a list
 */
export declare function flattenTree(node: AccessibleNode, depth?: number): {
    node: AccessibleNode;
    depth: number;
}[];
/**
 * Filter tree nodes by role
 */
export declare function filterByRole(node: AccessibleNode, roles: string[]): AccessibleNode[];
declare const _default: {
    buildAccessibilityTree: typeof buildAccessibilityTree;
    getAccessibleName: typeof getAccessibleName;
    getAccessibleDescription: typeof getAccessibleDescription;
    getAccessibleRole: typeof getAccessibleRole;
    getAriaStates: typeof getAriaStates;
    computeAriaProperties: typeof computeAriaProperties;
    flattenTree: typeof flattenTree;
    filterByRole: typeof filterByRole;
};
export default _default;
//# sourceMappingURL=accessibility-tree.d.ts.map