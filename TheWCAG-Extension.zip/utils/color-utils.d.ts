import { RgbColor, HslColor, ContrastResult } from '../types';
/**
 * Parse a CSS color string into RGB values
 */
export declare function parseColor(color: string): RgbColor | null;
/**
 * Check if a color is transparent
 */
export declare function isTransparent(color: string): boolean;
/**
 * Convert RGB to hex string
 */
export declare function rgbToHex(rgb: RgbColor): string;
/**
 * Convert hex to RGB
 */
export declare function hexToRgb(hex: string): RgbColor | null;
/**
 * Convert RGB to HSL
 */
export declare function rgbToHsl(rgb: RgbColor): HslColor;
/**
 * Convert HSL to RGB
 */
export declare function hslToRgb(hsl: HslColor): RgbColor;
/**
 * Calculate relative luminance of a color
 * Based on WCAG 2.1 formula
 */
export declare function calculateLuminance(rgb: RgbColor): number;
/**
 * Calculate contrast ratio between two colors
 * Returns a value between 1 and 21
 */
export declare function calculateContrastRatio(fg: RgbColor, bg: RgbColor): number;
/**
 * Check if contrast ratio passes WCAG requirements
 */
export declare function checkContrast(fg: RgbColor, bg: RgbColor, isLargeText?: boolean): ContrastResult;
/**
 * Darken a color by a percentage
 */
export declare function darken(rgb: RgbColor, percent: number): RgbColor;
/**
 * Lighten a color by a percentage
 */
export declare function lighten(rgb: RgbColor, percent: number): RgbColor;
/**
 * Adjust saturation of a color
 */
export declare function saturate(rgb: RgbColor, percent: number): RgbColor;
/**
 * Get a contrasting color (black or white)
 */
export declare function getContrastingColor(rgb: RgbColor): RgbColor;
/**
 * Suggest a better contrast color
 */
export declare function suggestBetterContrast(fg: RgbColor, bg: RgbColor, isLargeText?: boolean): RgbColor;
/**
 * Blend two colors with alpha
 */
export declare function blendColors(fg: RgbColor, bg: RgbColor, alpha?: number): RgbColor;
/**
 * Overlay color calculation (for semi-transparent overlays)
 */
export declare function overlayColor(fg: RgbColor, fgAlpha: number, bg: RgbColor): RgbColor;
/**
 * Check if a color is "light" (high luminance)
 */
export declare function isLightColor(rgb: RgbColor): boolean;
/**
 * Check if a color is "dark" (low luminance)
 */
export declare function isDarkColor(rgb: RgbColor): boolean;
/**
 * Get grayscale equivalent of a color
 */
export declare function toGrayscale(rgb: RgbColor): RgbColor;
/**
 * Check if two colors are visually similar
 */
export declare function areColorsSimilar(c1: RgbColor, c2: RgbColor, threshold?: number): boolean;
/**
 * Convert RGB to CSS rgb() string
 */
export declare function rgbToCss(rgb: RgbColor): string;
/**
 * Convert RGB to CSS rgba() string with alpha
 */
export declare function rgbaToCss(rgb: RgbColor, alpha?: number): string;
/**
 * Convert HSL to CSS hsl() string
 */
export declare function hslToCss(hsl: HslColor): string;
/**
 * Check if contrast ratio passes WCAG AA
 */
export declare function passesWCAG_AA(ratio: number, isLargeText?: boolean): boolean;
/**
 * Check if contrast ratio passes WCAG AAA
 */
export declare function passesWCAG_AAA(ratio: number, isLargeText?: boolean): boolean;
/**
 * Format contrast ratio for display
 */
export declare function formatContrastRatio(ratio: number): string;
/**
 * Check if text is large (18pt+ or 14pt+ bold)
 */
export declare function isLargeText(fontSize: number, fontWeight: string | number): boolean;
/**
 * Adjust lightness of a color to improve contrast
 */
export declare function adjustLightness(rgb: RgbColor, targetRatio: number, bgRgb: RgbColor): RgbColor;
//# sourceMappingURL=color-utils.d.ts.map