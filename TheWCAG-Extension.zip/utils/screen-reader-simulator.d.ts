import { AccessibleNode, ScreenReaderOutput, ScreenReaderNodeType } from '../types';
/**
 * Generate announcement for a single node
 */
export declare function formatAnnouncement(node: AccessibleNode): string;
/**
 * Generate screen reader preview from accessibility tree
 */
export declare function generateScreenReaderPreview(tree: AccessibleNode, depth?: number): ScreenReaderOutput[];
/**
 * Filter preview by navigation mode
 */
export declare function filterByMode(outputs: ScreenReaderOutput[], mode: string): ScreenReaderOutput[];
/**
 * Get navigation mode shortcuts (like screen readers)
 */
export declare function getNavigationModes(): {
    key: string;
    mode: string;
    description: string;
}[];
/**
 * Get preview statistics
 */
export declare function getPreviewStats(outputs: ScreenReaderOutput[]): {
    total: number;
    byType: Record<ScreenReaderNodeType, number>;
    issues: number;
};
/**
 * Export preview as plain text
 */
export declare function exportAsText(outputs: ScreenReaderOutput[]): string;
/**
 * Generate a full preview from the current page
 */
export declare function generateFullPreview(): ScreenReaderOutput[];
declare const _default: {
    generateScreenReaderPreview: typeof generateScreenReaderPreview;
    filterByMode: typeof filterByMode;
    formatAnnouncement: typeof formatAnnouncement;
    getNavigationModes: typeof getNavigationModes;
    getPreviewStats: typeof getPreviewStats;
    exportAsText: typeof exportAsText;
    generateFullPreview: typeof generateFullPreview;
};
export default _default;
//# sourceMappingURL=screen-reader-simulator.d.ts.map