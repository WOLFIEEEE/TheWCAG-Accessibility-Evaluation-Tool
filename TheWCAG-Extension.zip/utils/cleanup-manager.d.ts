type CleanupFunction = () => void;
/**
 * Manages cleanup of resources to prevent memory leaks
 */
declare class CleanupManager {
    private elements;
    private listeners;
    private observers;
    private intervals;
    private timeouts;
    private cleanupFunctions;
    private isCleanedUp;
    /**
     * Register an element for cleanup
     */
    registerElement(element: Element): void;
    /**
     * Register an event listener for cleanup
     */
    registerListener(target: EventTarget, event: string, listener: EventListener, options?: AddEventListenerOptions): void;
    /**
     * Register a MutationObserver for cleanup
     */
    registerObserver(observer: MutationObserver): void;
    /**
     * Register an interval for cleanup
     */
    registerInterval(id: number): void;
    /**
     * Register a timeout for cleanup
     */
    registerTimeout(id: number): void;
    /**
     * Register a custom cleanup function
     */
    registerCleanup(fn: CleanupFunction): void;
    /**
     * Create a managed interval
     */
    setInterval(callback: () => void, ms: number): number;
    /**
     * Create a managed timeout
     */
    setTimeout(callback: () => void, ms: number): number;
    /**
     * Clear a specific interval
     */
    clearInterval(id: number): void;
    /**
     * Clear a specific timeout
     */
    clearTimeout(id: number): void;
    /**
     * Perform full cleanup of all registered resources
     */
    cleanup(): void;
    /**
     * Check if cleanup has been performed
     */
    isCleanup(): boolean;
    /**
     * Reset the manager (for reuse after cleanup)
     */
    reset(): void;
    /**
     * Get statistics about tracked resources
     */
    getStats(): {
        elements: number;
        listeners: number;
        observers: number;
        intervals: number;
        timeouts: number;
        cleanupFunctions: number;
    };
}
export declare const cleanupManager: CleanupManager;
export declare function createCleanupManager(): CleanupManager;
/**
 * Decorator to wrap a function with cleanup registration
 */
export declare function withCleanup(manager: CleanupManager): <T extends (...args: unknown[]) => unknown>(_target: unknown, _propertyKey: string, descriptor: PropertyDescriptor) => PropertyDescriptor;
export default CleanupManager;
//# sourceMappingURL=cleanup-manager.d.ts.map