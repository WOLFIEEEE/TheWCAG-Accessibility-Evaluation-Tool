import { ElementInfo, BoundingRect } from '../types';
/**
 * Generate a CSS selector for an element
 */
export declare function getSelector(element: Element): string;
/**
 * Generate XPath for an element
 */
export declare function getXPath(element: Element): string;
/**
 * Get the accessible name of an element
 * Based on accessible name computation algorithm
 */
export declare function getAccessibleName(element: Element): string;
/**
 * Get the text content of an element, excluding hidden content
 */
export declare function getTextContent(element: Element): string;
/**
 * Get the associated label for a form control
 */
export declare function getAssociatedLabel(element: HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement): HTMLLabelElement | null;
/**
 * Check if an element is visible
 */
export declare function isElementVisible(element: Element): boolean;
/**
 * Check if an element is interactable
 */
export declare function isElementInteractable(element: Element): boolean;
/**
 * Get comprehensive information about an element
 */
export declare function getElementInfo(element: Element): ElementInfo;
/**
 * Check if an element is natively interactive
 */
export declare function isInteractiveElement(element: Element): boolean;
/**
 * Get element bounding rectangle
 */
export declare function getBoundingRect(element: Element): BoundingRect;
/**
 * Check if an element has a valid language attribute
 */
export declare function hasValidLanguage(element: Element): boolean;
/**
 * Get the language of an element (inherited if not set)
 */
export declare function getElementLanguage(element: Element): string | null;
/**
 * Get all focusable elements in order
 */
export declare function getFocusableElements(root?: Element): Element[];
/**
 * Get all headings in document order
 */
export declare function getHeadings(root?: Element): Element[];
/**
 * Get all landmarks in the document
 */
export declare function getLandmarks(root?: Element): Element[];
/**
 * Scroll an element into view smoothly
 */
export declare function scrollToElement(element: Element, options?: ScrollIntoViewOptions): void;
/**
 * Check if an element is in the viewport
 */
export declare function isInViewport(element: Element): boolean;
/**
 * Highlight an element temporarily
 */
export declare function highlightElement(element: Element, duration?: number): void;
/**
 * Add a persistent highlight box around an element
 */
export declare function addHighlightBox(element: Element, color?: string): HTMLElement;
/**
 * Remove all highlight boxes
 */
export declare function removeAllHighlightBoxes(): void;
/**
 * Get the navigation (tab) order of all focusable elements
 */
export declare function getNavigationOrder(root?: Element): {
    items: Array<{
        index: number;
        element: Element;
        tagName: string;
        type?: string;
        text: string;
        tabIndex: number;
        isNative: boolean;
    }>;
    totalCount: number;
};
/**
 * Serialize an element for messaging (can't pass Element objects directly)
 */
export declare function serializeElement(element: Element): {
    tagName: string;
    id: string;
    className: string;
    selector: string;
    xpath: string;
    text: string;
    outerHTML: string;
};
//# sourceMappingURL=dom-utils.d.ts.map