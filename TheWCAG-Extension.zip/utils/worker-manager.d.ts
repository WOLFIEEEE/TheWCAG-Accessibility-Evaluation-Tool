/**
 * WorkerManager handles communication with web workers
 */
export declare class WorkerManager {
    private worker;
    private pendingTasks;
    private taskIdCounter;
    private workerUrl;
    private isTerminated;
    constructor(workerUrl: string);
    /**
     * Initialize the worker
     */
    private ensureWorker;
    /**
     * Handle incoming messages from the worker
     */
    private handleMessage;
    /**
     * Handle worker errors
     */
    private handleError;
    /**
     * Send a task to the worker and get a promise for the result
     */
    execute<T>(type: string, data: unknown, timeoutMs?: number): Promise<T>;
    /**
     * Compute contrast ratios in batch
     */
    computeContrastBatch(pairs: Array<{
        foreground: string;
        background: string;
    }>): Promise<Array<{
        ratio: number;
        passAA: boolean;
        passAAA: boolean;
    }>>;
    /**
     * Analyze heading structure
     */
    analyzeStructure(headings: Array<{
        level: number;
        text: string;
        index: number;
    }>): Promise<Array<{
        type: string;
        message: string;
        index: number;
    }>>;
    /**
     * Terminate the worker
     */
    terminate(): void;
    /**
     * Check if worker is available
     */
    isAvailable(): boolean;
}
/**
 * Get the evaluation worker instance
 */
export declare function getEvaluationWorker(): WorkerManager | null;
/**
 * Terminate all workers
 */
export declare function terminateAllWorkers(): void;
export default WorkerManager;
//# sourceMappingURL=worker-manager.d.ts.map