/**
 * Escape HTML special characters to prevent XSS
 */
export declare function escapeHtml(text: string): string;
/**
 * Unescape HTML entities
 */
export declare function unescapeHtml(html: string): string;
/**
 * Sanitize HTML string - removes scripts and event handlers
 */
export declare function sanitizeHtml(html: string): string;
/**
 * Validate and sanitize a CSS selector
 */
export declare function sanitizeSelector(selector: string): string;
/**
 * Validate a URL is safe
 */
export declare function isValidUrl(url: string): boolean;
/**
 * Sanitize URL - only allow safe protocols
 */
export declare function sanitizeUrl(url: string): string;
/**
 * Sanitize JSON data - ensure only safe types
 */
export declare function sanitizeJson<T>(data: T): T;
/**
 * Create a safe text node (no HTML injection possible)
 */
export declare function createSafeTextNode(text: string): Text;
/**
 * Set text content safely
 */
export declare function setTextContent(element: Element, text: string): void;
/**
 * Set attribute safely
 */
export declare function setAttributeSafe(element: Element, name: string, value: string): void;
/**
 * Create element with safe attributes
 */
export declare function createElementSafe(tagName: string, attributes?: Record<string, string>, textContent?: string): Element;
/**
 * Validate element selector matches expected element
 */
export declare function validateElement(selector: string, expectedTag?: string): Element | null;
//# sourceMappingURL=sanitize.d.ts.map