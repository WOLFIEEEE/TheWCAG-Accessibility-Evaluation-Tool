export interface ErrorLog {
    timestamp: number;
    type: 'error' | 'warning' | 'info';
    source: 'content' | 'sidebar' | 'analyzer' | 'background';
    message: string;
    stack?: string;
    context?: Record<string, unknown>;
}
/**
 * Log an error to the internal log
 */
export declare function logError(source: ErrorLog['source'], error: Error | string, context?: Record<string, unknown>): void;
/**
 * Log a warning
 */
export declare function logWarning(source: ErrorLog['source'], message: string, context?: Record<string, unknown>): void;
/**
 * Log info
 */
export declare function logInfo(source: ErrorLog['source'], message: string, context?: Record<string, unknown>): void;
/**
 * Get all error logs
 */
export declare function getErrorLogs(): ErrorLog[];
/**
 * Clear error logs
 */
export declare function clearErrorLogs(): void;
/**
 * Setup global error handlers for a context
 */
export declare function setupGlobalErrorHandlers(source: ErrorLog['source']): void;
/**
 * Wrap an async function with error handling
 */
export declare function withErrorHandling<T extends (...args: unknown[]) => Promise<unknown>>(fn: T, source: ErrorLog['source'], context?: Record<string, unknown>): T;
/**
 * Safe execution wrapper - catches errors and returns null
 */
export declare function safeExecute<T>(fn: () => T, source: ErrorLog['source'], fallback?: T | null): T | null;
/**
 * Safe async execution wrapper
 */
export declare function safeExecuteAsync<T>(fn: () => Promise<T>, source: ErrorLog['source'], fallback?: T | null): Promise<T | null>;
/**
 * Retry wrapper for async operations
 */
export declare function retryAsync<T>(fn: () => Promise<T>, options?: {
    maxRetries?: number;
    delay?: number;
    backoff?: number;
    source?: ErrorLog['source'];
}): Promise<T>;
//# sourceMappingURL=error-handler.d.ts.map