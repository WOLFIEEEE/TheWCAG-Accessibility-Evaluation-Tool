import { EvaluationResults, HeadingInfo, LandmarkInfo } from '../types';
export interface AccessibilityReport {
    metadata: ReportMetadata;
    summary: ReportSummary;
    issues: ReportIssue[];
    pageInfo: PageInfo;
}
export interface ReportMetadata {
    url: string;
    title: string;
    timestamp: string;
    toolName: string;
    toolVersion: string;
    wcagVersion: string;
    conformanceLevel: 'A' | 'AA' | 'AAA';
}
export interface ReportSummary {
    score: number;
    totalIssues: number;
    errors: number;
    alerts: number;
    features: number;
    structure: number;
    aria: number;
    contrast: number;
    byImpact: {
        critical: number;
        serious: number;
        moderate: number;
        minor: number;
    };
}
export interface ReportIssue {
    id: string;
    ruleId: string;
    category: string;
    impact: string;
    message: string;
    selector: string;
    wcagCriteria: string[];
    howToFix?: string;
}
export interface PageInfo {
    title: string;
    url: string;
    language: string;
    headings: HeadingInfo[];
    landmarks: LandmarkInfo[];
    totalElements: number;
}
/**
 * Generate a comprehensive accessibility report
 */
export declare function generateReport(results: EvaluationResults, options: {
    url: string;
    title: string;
    headings?: HeadingInfo[];
    landmarks?: LandmarkInfo[];
    conformanceLevel?: 'A' | 'AA' | 'AAA';
}): AccessibilityReport;
/**
 * Export report as JSON string
 */
export declare function exportToJSON(report: AccessibilityReport): string;
/**
 * Download report as JSON file
 */
export declare function downloadJSON(report: AccessibilityReport, filename?: string): void;
/**
 * Export report as CSV string
 */
export declare function exportToCSV(report: AccessibilityReport): string;
/**
 * Download report as CSV file
 */
export declare function downloadCSV(report: AccessibilityReport, filename?: string): void;
/**
 * Export report as HTML string
 */
export declare function exportToHTML(report: AccessibilityReport): string;
/**
 * Download report as HTML file
 */
export declare function downloadHTML(report: AccessibilityReport, filename?: string): void;
/**
 * Export report as EARL (Evaluation and Report Language) JSON-LD
 */
export declare function exportToEARL(report: AccessibilityReport): string;
/**
 * Download report as EARL file
 */
export declare function downloadEARL(report: AccessibilityReport, filename?: string): void;
/**
 * Copy report to clipboard
 */
export declare function copyReportToClipboard(report: AccessibilityReport): Promise<boolean>;
/**
 * Format report as plain text
 */
export declare function formatReportAsText(report: AccessibilityReport): string;
//# sourceMappingURL=report-generator.d.ts.map