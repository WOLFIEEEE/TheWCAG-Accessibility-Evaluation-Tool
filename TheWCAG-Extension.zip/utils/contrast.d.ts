import { RgbColor, HslColor } from '../types';
/**
 * Parse a color string into RGB components
 * Supports: hex (#RGB, #RRGGBB), rgb(), rgba(), named colors
 *
 * @param color - Color string to parse
 * @returns RGB color object or null if invalid
 *
 * @example
 * parseColor('#FF0000')  // { r: 255, g: 0, b: 0 }
 * parseColor('rgb(255, 128, 0)')  // { r: 255, g: 128, b: 0 }
 * parseColor('red')  // { r: 255, g: 0, b: 0 }
 */
export declare function parseColor(color: string | null | undefined): RgbColor | null;
/**
 * Convert RGB color to hexadecimal string
 *
 * @param color - RGB color object
 * @returns Hex color string (lowercase, with #)
 *
 * @example
 * rgbToHex({ r: 255, g: 0, b: 0 })  // '#ff0000'
 */
export declare function rgbToHex(color: RgbColor): string;
/**
 * Convert RGB color to HSL color space
 *
 * @param color - RGB color object
 * @returns HSL color object (h: 0-360, s: 0-100, l: 0-100)
 *
 * @example
 * rgbToHsl({ r: 255, g: 0, b: 0 })  // { h: 0, s: 100, l: 50 }
 */
export declare function rgbToHsl(color: RgbColor): HslColor;
/**
 * Convert HSL color to RGB color space
 *
 * @param color - HSL color object (h: 0-360, s: 0-100, l: 0-100)
 * @returns RGB color object
 *
 * @example
 * hslToRgb({ h: 0, s: 100, l: 50 })  // { r: 255, g: 0, b: 0 }
 */
export declare function hslToRgb(color: HslColor): RgbColor;
/**
 * Calculate the relative luminance of a color
 * Per WCAG 2.1 definition
 *
 * @param color - RGB color object
 * @returns Relative luminance (0-1)
 *
 * @see https://www.w3.org/WAI/GL/wiki/Relative_luminance
 */
export declare function getLuminance(color: RgbColor): number;
/**
 * Calculate the contrast ratio between two colors
 * Per WCAG 2.1 definition
 *
 * @param fg - Foreground RGB color
 * @param bg - Background RGB color
 * @returns Contrast ratio (1-21)
 *
 * @see https://www.w3.org/WAI/GL/wiki/Contrast_ratio
 *
 * @example
 * getContrastRatio({ r: 0, g: 0, b: 0 }, { r: 255, g: 255, b: 255 })  // ~21
 */
export declare function getContrastRatio(fg: RgbColor, bg: RgbColor): number;
/**
 * Check if contrast ratio meets WCAG 2.1 Level AA requirements
 *
 * @param ratio - Contrast ratio
 * @param isLargeText - Whether text is large (18pt+ or 14pt+ bold)
 * @returns True if passes AA
 *
 * @example
 * meetsWCAGAA(4.5, false)  // true (normal text)
 * meetsWCAGAA(3, true)     // true (large text)
 */
export declare function meetsWCAGAA(ratio: number, isLargeText?: boolean): boolean;
/**
 * Check if contrast ratio meets WCAG 2.1 Level AAA requirements
 *
 * @param ratio - Contrast ratio
 * @param isLargeText - Whether text is large (18pt+ or 14pt+ bold)
 * @returns True if passes AAA
 *
 * @example
 * meetsWCAGAAA(7, false)   // true (normal text)
 * meetsWCAGAAA(4.5, true)  // true (large text)
 */
export declare function meetsWCAGAAA(ratio: number, isLargeText?: boolean): boolean;
/**
 * Format a contrast ratio for display
 *
 * @param ratio - Contrast ratio
 * @returns Formatted string (e.g., "4.50:1")
 */
export declare function formatContrastRatio(ratio: number): string;
/**
 * Blend a foreground color with a background color using alpha
 *
 * @param fg - Foreground RGB color
 * @param bg - Background RGB color
 * @param alpha - Alpha value (0-1)
 * @returns Blended RGB color
 */
export declare function blendColors(fg: RgbColor, bg: RgbColor, alpha: number): RgbColor;
/**
 * Suggested color fix with metadata
 */
export interface ColorSuggestion {
    color: RgbColor;
    hex: string;
    contrastRatio: number;
    meetsAA: boolean;
    meetsAAA: boolean;
}
/**
 * Suggest color fixes to improve contrast
 *
 * @param fg - Current foreground color
 * @param bg - Current background color
 * @param isLargeText - Whether text is large
 * @returns Array of suggested colors with improved contrast
 */
export declare function suggestColorFixes(fg: RgbColor, bg: RgbColor, isLargeText?: boolean): ColorSuggestion[];
/**
 * Calculate the optimal text color (black or white) for a given background
 *
 * @param bg - Background RGB color
 * @returns Either black or white, whichever has better contrast
 */
export declare function getOptimalTextColor(bg: RgbColor): RgbColor;
/**
 * Check if a color is considered "light"
 *
 * @param color - RGB color
 * @returns True if the color is light
 */
export declare function isLightColor(color: RgbColor): boolean;
/**
 * Adjust color lightness by a percentage
 *
 * @param color - RGB color
 * @param percent - Percentage to adjust (-100 to 100)
 * @returns Adjusted RGB color
 */
export declare function adjustLightness(color: RgbColor, percent: number): RgbColor;
/**
 * Get the effective background color by walking up the DOM tree
 * and compositing transparent backgrounds
 *
 * @param element - Target element
 * @returns Effective background RGB color
 */
export declare function getEffectiveBackgroundColor(element: Element): RgbColor;
/**
 * Get the foreground color of an element
 *
 * @param element - Target element
 * @returns Foreground RGB color
 */
export declare function getForegroundColor(element: Element): RgbColor | null;
/**
 * Analyze the contrast of an element
 *
 * @param element - Target element
 * @returns Contrast analysis result
 */
export declare function analyzeElementContrast(element: Element): {
    foreground: RgbColor;
    background: RgbColor;
    ratio: number;
    meetsAA: boolean;
    meetsAAA: boolean;
    isLargeText: boolean;
} | null;
//# sourceMappingURL=contrast.d.ts.map