import { CustomRule, RuleResult } from '../types';
/**
 * Evaluate a single custom rule against an element
 */
export declare function evaluateCustomRule(element: Element, rule: CustomRule): boolean;
/**
 * Run all custom rules on the document
 */
export declare function evaluateCustomRules(rules: CustomRule[], doc?: Document): RuleResult[];
/**
 * Validate a custom rule definition
 */
export declare function validateCustomRule(rule: Partial<CustomRule>): {
    valid: boolean;
    errors: string[];
};
/**
 * Get preset custom rule templates
 */
export declare function getCustomRulePresets(): Partial<CustomRule>[];
declare const _default: {
    evaluateCustomRule: typeof evaluateCustomRule;
    evaluateCustomRules: typeof evaluateCustomRules;
    validateCustomRule: typeof validateCustomRule;
    getCustomRulePresets: typeof getCustomRulePresets;
};
export default _default;
//# sourceMappingURL=custom-rules.d.ts.map