import { ExtensionSettings, IgnorePattern, CustomRule, SiteProfile, WcagLevel } from '../types';
/**
 * Load settings from Chrome storage
 */
export declare function loadSettings(): Promise<ExtensionSettings>;
/**
 * Save settings to Chrome storage
 */
export declare function saveSettings(settings: ExtensionSettings): Promise<boolean>;
/**
 * Clear the settings cache
 */
export declare function clearCache(): void;
/**
 * Add a new ignore pattern
 */
export declare function addIgnorePattern(pattern: Omit<IgnorePattern, 'id' | 'createdAt'>): Promise<IgnorePattern>;
/**
 * Update an existing ignore pattern
 */
export declare function updateIgnorePattern(id: string, updates: Partial<Omit<IgnorePattern, 'id' | 'createdAt'>>): Promise<boolean>;
/**
 * Remove an ignore pattern
 */
export declare function removeIgnorePattern(id: string): Promise<boolean>;
/**
 * Get all enabled ignore patterns
 */
export declare function getEnabledIgnorePatterns(): Promise<IgnorePattern[]>;
/**
 * Add a new custom rule
 */
export declare function addCustomRule(rule: Omit<CustomRule, 'id' | 'createdAt'>): Promise<CustomRule>;
/**
 * Update an existing custom rule
 */
export declare function updateCustomRule(id: string, updates: Partial<Omit<CustomRule, 'id' | 'createdAt'>>): Promise<boolean>;
/**
 * Remove a custom rule
 */
export declare function removeCustomRule(id: string): Promise<boolean>;
/**
 * Get all enabled custom rules
 */
export declare function getEnabledCustomRules(): Promise<CustomRule[]>;
/**
 * Get site profile for a domain
 */
export declare function getSiteProfile(domain: string): Promise<SiteProfile | null>;
/**
 * Create or update site profile
 */
export declare function updateSiteProfile(domain: string, updates: Partial<Omit<SiteProfile, 'domain'>>): Promise<SiteProfile>;
/**
 * Remove site profile
 */
export declare function removeSiteProfile(domain: string): Promise<boolean>;
/**
 * Get ignore patterns for a specific site
 */
export declare function getIgnorePatternsForSite(domain: string): Promise<IgnorePattern[]>;
/**
 * Get custom rules for a specific site
 */
export declare function getCustomRulesForSite(domain: string): Promise<CustomRule[]>;
/**
 * Export settings as JSON string
 */
export declare function exportSettings(): Promise<string>;
/**
 * Import settings from JSON string
 */
export declare function importSettings(json: string): Promise<boolean>;
/**
 * Reset settings to defaults
 */
export declare function resetSettings(): Promise<boolean>;
/**
 * Get WCAG level setting
 */
export declare function getDefaultWcagLevel(): Promise<WcagLevel>;
/**
 * Set WCAG level setting
 */
export declare function setDefaultWcagLevel(level: WcagLevel): Promise<boolean>;
/**
 * Toggle global ignore
 */
export declare function toggleGlobalIgnore(enabled: boolean): Promise<boolean>;
/**
 * Get settings statistics
 */
export declare function getSettingsStats(): Promise<{
    ignorePatterns: number;
    customRules: number;
    siteProfiles: number;
}>;
//# sourceMappingURL=settings-manager.d.ts.map