import { Message, MessageAction, PortMessage } from '../types';
/**
 * Check if extension context is still valid
 * This prevents "Extension context invalidated" errors
 */
export declare function isContextValid(): boolean;
/**
 * Safe wrapper for chrome API calls
 */
export declare function safeChrome<T>(fn: () => T, fallback: T): T;
/**
 * Safe port connection with error handling
 */
export declare function safeConnect(tabId: number, name: string): chrome.runtime.Port | null;
/**
 * Safe port message posting
 */
export declare function safePostMessage(port: chrome.runtime.Port | null, message: PortMessage): boolean;
/**
 * Send message to content script
 */
export declare function sendToContentScript<T>(tabId: number, action: MessageAction, data?: T): Promise<void>;
/**
 * Send message to sidebar
 */
export declare function sendToSidebar<T>(tabId: number, action: MessageAction, data?: T): Promise<void>;
/**
 * Wake service worker
 */
export declare function wakeServiceWorker(): Promise<void>;
/**
 * Dispatch custom event on document
 */
export declare function dispatchCustomEvent<T>(eventName: string, data?: T): void;
/**
 * Listen for custom event on document
 */
export declare function listenForCustomEvent<T>(eventName: string, callback: (data: T) => void): () => void;
/**
 * Create message payload
 */
export declare function createMessage<T>(action: MessageAction, data?: T): Message<T>;
/**
 * Retry operation with exponential backoff
 */
export declare function retryWithBackoff<T>(operation: () => Promise<T>, maxRetries?: number, baseDelay?: number): Promise<T>;
/**
 * Ping tab to check if content script is active
 */
export declare function pingContentScript(tabId: number): Promise<boolean>;
/**
 * Ensure content script is injected and ready
 */
export declare function ensureContentScript(tabId: number): Promise<void>;
//# sourceMappingURL=messaging.d.ts.map